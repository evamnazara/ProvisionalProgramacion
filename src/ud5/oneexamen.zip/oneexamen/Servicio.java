//Eva María Otero Názara 

package ud5.oneexamen;

public class Servicio extends Servidor {

    public Servicio(String nombreServicio, String puerto, String protocolo) {
        super(nombreServicio, nombreServicio, protocolo);
    }
    
    
}
